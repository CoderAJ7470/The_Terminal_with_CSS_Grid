Thank you for downloading Turbofan's Super King Air Repaint Pack 2 (TF-SKARP 2).

You will find the installation instructions here as well as descriptions of all 10 repaints in this second pack.

To install:

1. Copy/paste airTFankingair200_2.lst into the "aircraft" folder located in the YS FLIGHT main folder.
2. Copy/paste TF-SKARP_2 into your "user" folder, also located in the main YS FLIGHT folder.

Credits: Taskforce 58; http://www.ysflight.ca

NOTE: You will need Taskforce 58's Super King Air 200 already installed for the instrument panel to work.
----------------------------------------------------------------------------------------------------------------------------------------

**Released November 18, 2014.**

These 10 repaints make up the second pack in the TF-SKARP series. Similar to the first pack, all repaints have been created simply with the find-and-replace function in Notepad to repaint all 13 sections of the Super King Air 200. Also similar to the first pack, the repaints are based on colour combinations I saw in real life or just combinations that popped into my head, which I thought would look nice on the aircraft. Or it was an airline scheme that I thought I can apply to the default layout of the body, engine and rudder lines, mixing and matching along the way to make it presentable. I have also added some EXCAMERA (extra camera) positions, namely, the first officer position (includes the HUD or instrument panel, whatever you have chosen to display), two "shoulder cam" positions just above each pilot's shoulder, and two cabin positions.

Below are the descriptions of each repaint.

KINGAIR200_Business_Lady: The inspiration for this comes from a lady in a dark business suit, dressed up and ready to go for business. The red stripe signifies red lipstick.

KINGAIR200_Tri_Colour: India's flag colours on the King Air. I kept the engines white to contrast with the indigo blue on the fuselage, while the stripes alternate as either orange and green on the engines or white and green on the tail, to match the orange, white and green stripes on the actual flag. The indigo blue on the fuselage is for the colour of the "chakra", or wheel, in the center of the flag.

KINGAIR200_Eco_Plane: A repaint that symbolizes the "going green" theme these days. So not much to say for this one except I made the fuselage a lighter green and gave the stripes a contrasting dark green to balance everythiing out. **NOTE: This repaint's .dat file actually has a lower fuel burn rate than the default burn rate assigned to other King Airs (after all it is an eco-plane right?).

KINGAIR200_Aqua-Blue: Aqua-blue on the fuselage with navy-blue on the tail and engines. Navy-blue, aqua-blue and white alternating stripes to balance out the colour scheme.

KINGAIR200_Southwest_Heart: I had already made versions of the original Desert-Brown and Canyon-Blue colour schemes of Southwest Airlines' livery on the King Air (in TF-SKARP 1). So naturally when Southwest came out with its latest colour scheme this year (the Southwest "Heart" scheme), I had to try and get it on the King Air as best as I could, while using the default layout of the repaintable parts. Thus this repaint, which has the yellow-gold on the tail and darker blue on the fuselage.

KINGAIR200_Police_Plane1: Better watch your back if this plane's flying behind you. Ok, so while it has no real policing capabilities, it is made to look like a flying police vehicle. Pretty self-explanatory with the black fuselage and engines, dark blue body and engine stripes and the white wings and horizontal stabilizer to give it that "police" effect.

KINGAIR200_Police_Plane2: A variation of the "Police_Plane1" colour scheme, with white engines and tail.

KINGAIR200_Autumn: Colours of Fall (read: leaves, Butterbut Squash and Pumpkins) on the Super King Air. The breakdown is as follows:

> Red-Orange on the fuselage and engines
> Butternut Squash skin on the wing and horizontal stabiliser
> Leaf brown on the prop spinners
> Pumpkin on the tail
> Faded brown and deep red on the body, engine and rudder lines

KINGAIR200_Shades_of_Purple: Pretty much what it says. Light/faded purple on the fuselage, purple itself on the wings and tail, and an "intermediate" shade of purple on the horizontal stabilizer, prop spinner and stripes.

KINGAIR200_Turquoise: What you see is what you get. Turquoise on the fuselage, engines and horizontal stabilizer, with alternating white and turquoise shades appear on the stripes.