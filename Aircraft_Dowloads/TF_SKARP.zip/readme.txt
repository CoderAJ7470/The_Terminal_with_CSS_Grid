**Updated January 24, 2012**

Raytheon Beechcraft Super Kingair 200 repaints.

These are my repainted versions of Taskforce 58's Beechcraft Super King Air 200. To install these repainted versions, copy and paste the "airTFankingair200.lst" file into your default YSFS aircraft folder.

After you've done that, just copy the "TF-SKARP" folder and paste it in the main YSFLIGHT folder.

Note: You will need Taskforce 58's aircraft pack for the instrument panel to work in all these repainted models.

Modification policy: You can modify these repaints if you wish, just credit me for the repaints and Taskforce 58 for the original model.

------------------------

Thanks for downloading this Kingair repaint pack. All made possible by Taskforce 58's coloringbase.dnm file which comes with the download of his Super King Air, otherwise I know nothing about repainting aircraft.

To download the original Super King Air made by him, go to http://www.ysflight.ca/index.php?page=downloads
You can also browse his site at www.ysflight.ca./

This pack also includes three Christmas-themed repaints I made-the Santa Plane, Peppermint Hot chocolate (PHC) and Candy Cane. They're one of the "Special Christmas" addons in the YSFHQ pack, released in December, 2012.

Descriptions of the original repaints:

KING_AIR_SOUTHWEST_DB: The main body is in Southwest Airlines' original desert brown, as are the engines. The lines are in red and orange.

KING_AIR_200_DREAMLINER: The original livery of the 787 Dreamliner is composed of a total of six different shades of blue and white, but since I only had the visual and not the detailed information on those, I tried to re-create it on the King Air as best as I could.

KING_AIR_SKITTLES_TROPICAL: Based on the original Skittles Tropical candy. There are five flavours represented on the plane, Passion Punch, Banana Berry, Kiwi Lime, Mango Peach and Strawberry Watermelon. This information can be found at http://www.candyblog.net/blog/item/skittles. Here's the breakdown by aircraft part:

Fuselage: Strawberry Watermelon

Wings: Mango Peach

Elevator: Passion Punch

Tail: Kiwi Lime

Windows: Banana Berry

I made the engines the default Skittles red. The stripes are either Kiwi Lime or Mango Peach, or just plain white.

KING_AIR_NORTHWEST_SILVER: Northwest Airlines' third and final colourscheme before it was merged into Delta. The colourscheme is based on the famous red tail and the all-silver body.

-----------------------------
July 3rd, 2008 additions.

"Corporate" Repaints. These are mainly just types of colour schemes you would find out there in the world of corporate aviation. Nothing in particular, just what came into my imagination.

KING AIR 200 AZURE GREEN: The bluish-green cheatline I actually did borrow from a plane I once saw on a website. I thought the lilac on the tail would go well with it.

KING AIR 200 PATRIOT: Well, it being July and since this release came on the weekend of the 4th, I decided to do a red-white-blue paint scheme and this is what I came up with. I kept the cheatlines red and white to document the stripes of the U.S. Flag and included red and blue on the tail and engines.

KING AIR 200 BUSINESS BLUE: I took the idea from a light blue business shirt and added a darker shade of blue to accent it on the tail and windows.

KING AIR BUSINESS BROWN: Brown and grey, some of the "most seen" colours of the corporate world.

KING AIR SOONER ONE and KING AIR SOONER TWO: Well, I attended the University of Oklahoma for quite a while so thus, these two colour schemes. The combination is Crimson and Cream, although I've seen two distinct different shades of the "crimson" on t-shirts and such, therefore two different shades for the planes as well.
-----------------------------
January 2nd, 2009 additions.

These are just some more random repaints, stuff that I put together conceptually.

KING AIR SUN: My main goal with this repaint was to replicate the different shades of orange and the yellow you see with the sun at different times of the day, at sunrise, when it's overhead and and at sunset. I used a red-orange, dull orange, and a toned-down yellow, with the purple sometimes seen in infrared images of the sun.

KING AIR BLUE SHADE HUES: Since I was doing something "hot", I wanted to complement it. Thus this repaint, comprising of 5 different shades of blue, including deep sky blue on the engines, navy blue on the fuselage and a slate blue on the horizontal stabiliser.

KING AIR FIREFLY: Definitely the craziest paint scheme I have ever done, an air traffic controller's worst nightmare. Essentially, as the name suggests, the main purpose of this paint scheme is to create the effect of a firefly at night. Fly it in nightmode for best results ;)

KING AIR CANDY CANE: Christmas on a plane. I used the cheatlines on the engines, body and rudder to create a candy cane, the green is pretty self-explanatory.
----------------------------
December 23rd, 2010 additions.

Once again, with some random repaints, this time though some based on airline colourschemes, and some on the holiday theme.

KING AIR PINK-N-PURPLE: Based on PatrickN's Pink-N-Purple planes.

KING AIR SANTA PLANE: The familar red and white of Santa Claus' uniform, with the "black belt" duplicated with the stripes on the engines, fuselage and rudder.

KING AIR PEPPERMINT HOT CHOCOLATE: This is a variation of my "Candy Cane" colourscheme, dark chocolate on the fuselage and milk chocolate on the horizontal stabliser with mint green on the prop spinners.

KING AIR PROVINCIAL AIRLINES: Based entirely on the Provincial Airlines colourscheme, but with some differences. The coloringbase.dnm file fits the actual Provincial colourscheme almost perfectly.

KING AIR BUSINESS BLUE 2: A "corporate" type repaint.

KING AIR FLAME: I saw the Hainan Airways livery and thought it would look good in a variation on the King Air 200. So I decided to paint it, the wings and tail are in a red-orange, the horizontal stabiliser and wings are red.
----------------------------
January 25th, 2012 additions.

Just colour combinations I thought would go well on the Super Kingair.

KINGAIR200_Rams: Based on the NFL's St. Louis Rams team colours. The dark blue is on the body, engine and tail, while the gold is used on the stripes and the horizontal stabilizer.

KINGAIR200_Whoppers_Candy: Malted milk balls that don't taste that great (in my opinion anyway), but the colour combination looks quite nice on the Super Kingair. It goes without saying the actual candy is represented on the round windows, while the wings and horizontal stabilizer represent the chocolate coating. The fuselage, tail and engines are painted in the malted milk colour.

Kingair_WN_Canyon_Blue: I updated the Canyon Blue livery I had done previously to more closely match the actual Canyon Blue seen on Southwest Airlines jets, with the naked eye. The blue is thus given a lighter tone.

KINGAIR200_Blue_And_Yellow: Nothing special, just a blue and yellow colourscheme I thought would look good on the plane.

KINGAIR200_Dreamliner2: Another variation of the Dreamliner colours, this time with a darker blue on the fuselage, the turquoise blue on the prop spinners and the greyish-blue on the horizontal stabiliser.